package com.jarvis.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.MediaStore
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var orb: TextView
    private lateinit var tts: TextToSpeech
    private var torchOn = false
    private var ttsReady = false
    private val requestAudio = 41
    private val requestSpeech = 42
    private val requestCamera = 43
    private val cyan = 0xFF39D8FF.toInt()
    private val muted = 0xFF91A7C4.toInt()
    private val panel = 0xFF101D31.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF050B16.toInt()
        window.navigationBarColor = 0xFF050B16.toInt()
        tts = TextToSpeech(this, this)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF070914.toInt()) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(20,24,20,14) }
        header.addView(label("✦  J.A.R.V.I.S", 27f, cyan, true))
        header.addView(label("NEURAL ASSISTANT  •  CYBER EDITION", 10f, muted, true))
        root.addView(header)
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER_HORIZONTAL; setPadding(18,8,18,24) }
        val hero = TextView(this).apply { text="◉"; textSize=90f; gravity=Gravity.CENTER; setTextColor(cyan); setPadding(0,18,0,4) }
        content.addView(hero)
        status = label("● SYSTEM ONLINE", 12f, 0xFF64F4D2.toInt(), true); content.addView(status)
        content.addView(label("Your personal command interface", 13f, muted, false).apply { setPadding(0,8,0,18) })
        val mic = actionButton("✦   ACTIVATE VOICE", cyan) { startListening() }; mic.textSize=16f; mic.setPadding(0,12,0,12); content.addView(mic)
        transcript = label("J.A.R.V.I.S. ready\nSpeak in Hindi, Hinglish or English.", 15f, 0xFFE8F2FF.toInt(), false).apply { gravity=Gravity.CENTER; setPadding(18,22,18,22); background=rounded(0xFF11162A.toInt(),22) }
        content.addView(transcript, LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,14,0,18) })
        content.addView(sectionTitle("✧  QUICK LAUNCH"))
        addActionRow(content,"▶ YouTube","◉ WhatsApp"); addActionRow(content,"⌕ Chrome","⚙ Settings")
        addActionRow(content,"ϟ Flashlight","▣ Camera"); addActionRow(content,"＋ Volume +","－ Volume -"); addActionRow(content,"⌂ Home","◷ Date & Time")
        content.addView(sectionTitle("✧  CAPABILITIES"))
        content.addView(infoCard("LOCAL COMMANDS", "Launch apps, control flashlight and volume, open camera, set alarms and check date or time."))
        content.addView(infoCard("VOICE INTERFACE", "Hindi / Hinglish speech input and spoken replies. Recognition availability depends on your device."))
        content.addView(infoCard("WEB SEARCH", "Say ‘search for…’ to launch a web search."))
        scroll.addView(content); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val footer=label("● CORE READY     •     JARVIS  /  03",10f,0xFF4C789A.toInt(),true).apply { setPadding(8,12,8,12) }; root.addView(footer)
        setContentView(root)
    }

    private fun label(textValue: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = textValue
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER
        if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
    }

    private fun sectionTitle(value: String): TextView = label(value, 11f, cyan, true).apply {
        gravity = Gravity.START
        setPadding(2, 18, 2, 8)
    }

    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            setStroke(1, 0xFF1D3A55.toInt())
        }

    private fun actionButton(value: String, color: Int, action: () -> Unit): Button = Button(this).apply {
        text = value
        setTextColor(if (color == cyan) 0xFF04111C.toInt() else android.graphics.Color.WHITE)
        setBackground(rounded(color, 16))
        isAllCaps = false
        textSize = 13f
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 5, 0, 5) }
    }

    private fun addActionRow(parent: LinearLayout, first: String, second: String) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(first, second).forEach { name ->
            val button = actionButton(name, panel) { runQuickAction(name) }
            val params = LinearLayout.LayoutParams(0, -2, 1f)
            params.setMargins(4, 4, 4, 4)
            row.addView(button, params)
        }
        parent.addView(row)
    }

    private fun infoCard(title: String, detail: String): TextView = TextView(this).apply {
        text = "$title\n$detail"
        textSize = 12f
        setTextColor(0xFFD5E5F7.toInt())
        setPadding(15, 13, 15, 13)
        background = rounded(panel, 14)
        val p = LinearLayout.LayoutParams(-1, -2)
        p.setMargins(0, 5, 0, 5)
        layoutParams = p
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
            status.text = "MICROPHONE PERMISSION NEEDED"
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS is listening — speak now")
        }
        try {
            status.text = "LISTENING..."
            orb.text = "◉  •••"
            startActivityForResult(intent, requestSpeech)
        } catch (_: Exception) {
            status.text = "SPEECH SERVICE UNAVAILABLE"
            speak("Speech recognition service available nahi hai. Phone mein offline Hindi voice pack check karein.")
        }
    }

    @Deprecated("Legacy speech result callback supports Android 10")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestSpeech) {
            orb.text = "◉"
            if (resultCode == RESULT_OK) {
                val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
                transcript.text = "YOU SAID\n$spoken"
                handleCommand(spoken)
            } else {
                status.text = "READY"
            }
        }
    }

    private fun normalize(value: String): String = value.lowercase(Locale.ROOT).trim()

    private fun handleCommand(raw: String) {
        val command = normalize(raw)
        status.text = "COMMAND RECEIVED"
        when {
            has(command, "torch", "flashlight", "टॉर्च", "फ्लैशलाइट") -> toggleTorch()
            has(command, "home", "होम", "घर") -> goHome()
            has(command, "volume up", "आवाज बढ़ा", "वॉल्यूम बढ़ा", "आवाज़ बढ़ा") -> adjustVolume(true)
            has(command, "volume down", "आवाज कम", "वॉल्यूम कम", "आवाज़ कम") -> adjustVolume(false)
            has(command, "volume", "आवाज", "आवाज़", "वॉल्यूम") -> adjustVolume(true)
            has(command, "youtube", "यूट्यूब") -> openApp("com.google.android.youtube", "YouTube")
            has(command, "whatsapp", "व्हाट्सएप") -> openApp("com.whatsapp", "WhatsApp")
            has(command, "chrome", "क्रोम", "browser", "ब्राउज़र") -> openApp("com.android.chrome", "Chrome")
            has(command, "setting", "सेटिंग") -> openSettings()
            has(command, "camera", "कैमरा", "photo", "फोटो") -> openCamera()
            has(command, "alarm", "अलार्म") -> setAlarm()
            has(command, "time", "समय", "कितने बजे") -> tellTime()
            has(command, "date", "तारीख", "आज कौन सा दिन") -> tellDate()
            has(command, "search", "खोजो", "सर्च") -> webSearch(raw)
            else -> {
                transcript.append("\n\nJARVIS: Is command ke liye online AI brain abhi connected nahi hai. Main isse supported command list mein add kar sakta hoon.")
                speak("Yeh command abhi mere offline command set mein nahi hai. Aap web search bolkar search kar sakte hain.")
            }
        }
    }

    private fun has(text: String, vararg words: String): Boolean = words.any { text.contains(it) }

    private fun runQuickAction(name: String) {
        when (name) {
            "YouTube" -> openApp("com.google.android.youtube", name)
            "WhatsApp" -> openApp("com.whatsapp", name)
            "Chrome" -> openApp("com.android.chrome", name)
            "Settings" -> openSettings()
            "Flashlight" -> toggleTorch()
            "Camera" -> openCamera()
            "Volume +" -> adjustVolume(true)
            "Volume -" -> adjustVolume(false)
            "Home" -> goHome()
            "Date & Time" -> tellTime()
        }
    }

    private fun openApp(packageName: String, displayName: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            speak("$displayName khol rahi hoon.")
            startActivity(launch)
        } else {
            speak("$displayName is phone par install nahi hai.")
            transcript.append("\n\n$displayName app nahi mili.")
        }
    }

    private fun toggleTorch() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), requestCamera)
            status.text = "CAMERA PERMISSION NEEDED FOR FLASHLIGHT"
            return
        }
        try {
            val manager = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = manager.cameraIdList.firstOrNull { manager.getCameraCharacteristics(it)
                .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id == null) { speak("Flashlight available nahi hai."); return }
            torchOn = !torchOn
            manager.setTorchMode(id, torchOn)
            speak(if (torchOn) "Flashlight on." else "Flashlight off.")
            status.text = if (torchOn) "FLASHLIGHT ON" else "SYSTEM READY"
        } catch (_: Exception) { speak("Flashlight control nahi ho paya.") }
    }

    private fun adjustVolume(up: Boolean) {
        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        speak(if (up) "Volume badha diya." else "Volume kam kar diya.")
    }

    private fun goHome() {
        speak("Home screen khol rahi hoon.")
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME))
    }

    private fun openSettings() {
        speak("Settings khol rahi hoon.")
        startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
    }

    private fun openCamera() {
        try {
            startActivity(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
            speak("Camera khol rahi hoon.")
        } catch (_: Exception) { speak("Camera app nahi mili.") }
    }

    private fun setAlarm() {
        try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            startActivity(intent)
            speak("Alarm set karne ka page khol diya hai.")
        } catch (_: Exception) { speak("Alarm app open nahi ho payi.") }
    }

    private fun tellTime() {
        val value = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        transcript.append("\n\nJARVIS: Abhi $value hai.")
        speak("Abhi $value hai.")
    }

    private fun tellDate() {
        val value = SimpleDateFormat("EEEE, d MMMM yyyy", Locale("hi", "IN")).format(Date())
        transcript.append("\n\nJARVIS: Aaj $value hai.")
        speak("Aaj $value hai.")
    }

    private fun webSearch(raw: String) {
        val query = raw.replace(Regex("(?i)\\b(search|search for|google|सर्च|खोजो)\\b"), "").trim()
        val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(query.ifBlank { raw }))
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
            speak("Internet par search kar rahi hoon.")
        } catch (_: Exception) { speak("Browser available nahi hai.") }
    }

    private fun speak(message: String) {
        if (ttsReady) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) {
            ttsReady = true
            val result = tts.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) tts.language = Locale.US
            val voices = tts.voices ?: emptySet()
            val femaleHindi = voices.firstOrNull { it.locale.language == "hi" &&
                (it.name.contains("female", true) || it.name.contains("woman", true)) }
            if (femaleHindi != null) tts.voice = femaleHindi
            tts.setSpeechRate(0.90f)
            tts.setPitch(1.08f)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestAudio && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startListening()
        if (requestCode == requestCamera && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) toggleTorch()
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
